//const { describe } = require("mocha");

//import { support } from "cypress/types/jquery"
import AmazonSearch from '../support/pageObjects/amazonSearch.spec'

const uiObj = new AmazonSearch()

//const input='Shoes'
//const brandfilter='T-Rock'
//const deliveryError='This item cannot be shipped to your selected delivery location. Please choose a different delivery location.'

describe('Amazon Product Search', function(){


    beforeEach(function(){
        cy.visit('/')
        cy.fixture('data.json').as('testData')
    })




    it('TC_01_SearchFrShoes', function(){

        
        uiObj.getSearchBox().type(this.testData.input)
        uiObj.getSubmitButton().click()

        // Assert header '1-48 of over 40,000 results for "Shoes"' includes text Shoes 
        uiObj.getSearchedResponse().should('include.text',this.testData.input)

        
    }) 

    it('TC_02_Apply Brand and Price filter', function(){

        
        uiObj.goToShoesSearch(this.testData.input)
        // Apply brand filter
        uiObj.getBrandFilter(this.testData.brandfilter).click()

        //assert brand filter
        uiObj.getFilteredData().then(res => {
            expect(res.text()).to.include(this.testData.brandfilter)
        })

        uiObj.getFilteredData2().then(res => {
            expect(res.text()).to.include(this.testData.brandfilter)
        })

        //Apply Under500 filter 

        uiObj.getUnder500Filter().click()
        uiObj.getPriceFilteredResponse().each(($el, index) => {
            expect(Number($el.text())).to.lessThan(500)
        })

    })    


    it('TC_03_Go to Product Details page and Added item to cart', function(){

        
        uiObj.goToShoesSearchAndApplyFilters(this.testData.input,this.testData.brandfilter)
        // Go to product details page
        uiObj.goToProductDetails().then( $a => {
            const href= $a.prop('href')
            cy.log(href)
            cy.visit(href)
        })

        uiObj.selectProductSize().select('6 UK')

        //Assert Product Details as per filter
        uiObj.getProductTitle().should('include.text', this.testData.brandfilter)

        //assert Delivery Error message on page
        uiObj.getDeliveryErrorMessage().should('include.text', this.testData.deliveryError)
       

        // Select DeliveryLocation 
        uiObj.selectDeliveryLocation().click()
        uiObj.enterPinCode().type('201301',{force:true})
        uiObj.applyAddress().click()

        //Assert delivery location
        uiObj.selectDeliveryLocation().should('include.text', '201301', {timeout:20000})

        //assert Quantity on product page -- should be 1 

        uiObj.getQuantity().should('have.value',1)

        //Add product to Cart
        uiObj.addToCart().click()

        //assert product added to cart
        uiObj.getAddedToCart().should('include.text', 'Added to Cart')






    })

})