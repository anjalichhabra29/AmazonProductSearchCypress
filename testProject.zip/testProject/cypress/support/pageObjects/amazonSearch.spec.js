/// <reference types = "Cypress" />



class AmazonSearch{


    getSearchBox(){
       return cy.get('#twotabsearchtextbox')
    }

    getSubmitButton(){
        return cy.get('#nav-search-submit-button')
    }

    getSearchedResponse(){
        return cy.get('.a-color-state')
    }

    getSerachItems(){
        return cy.get('[data-asin="B0886F939Y"] > .sg-col-inner > .celwidget > .s-expand-height > .a-spacing-medium > .a-spacing-top-small > .a-size-mini > .a-link-normal > .a-size-base-plus')
    }

    getBrandFilter(input){
        return cy.get('ul[aria-labelledby="p_89-title"]').contains(input).find('.a-icon')
        
    }

    getFilteredData(){

        return cy.get('[data-asin="B0886F939Y"] > .sg-col-inner > .celwidget > .s-expand-height > .a-spacing-medium > .a-spacing-top-small > .a-row > .s-line-clamp-1 > .a-size-base-plus')
    }

    getFilteredData2(){
        return cy.get('[data-asin="B089QKNCVR"] > .sg-col-inner > .celwidget > .s-expand-height > .a-spacing-medium > .a-spacing-top-small > .a-row > .s-line-clamp-1 > .a-size-base-plus')
    }

    getPriceFilteredResponse(){
        return cy.get('.a-price-whole')
    }

    getUnder500Filter(){
        return cy.get('ul[aria-labelledby="p_36-title"]').contains("Under ₹500")
    }

    goToProductDetails(){
        return cy.get('[data-asin="B0886F939Y"]').find('.a-link-normal')
    }

    selectProductSize(){
        return cy.get('#native_dropdown_selected_size_name')
    }

    selectDeliveryLocation(){
        return cy.get('#contextualIngressPtLabel_deliveryShortLine')
    }

    enterPinCode(){
        return cy.get('input[data-action="GLUXPostalInputAction"]',{timeout:30000})
        //cy.get('#GLUXZipUpdateInput',{timeout:30000})
    }

    applyAddress(){
        return cy.get('#GLUXZipUpdate')
    }

    getDeliveryErrorMessage(){
        return cy.get('#ddmDeliveryMessage > .a-color-error')
    }

    getQuantity(){
        return cy.get('#quantity')
    }

    addToCart(){
        return cy.get('#add-to-cart-button')
    }

    getAddedToCart(){
        return cy.get('#huc-v2-order-row-confirm-text > .a-size-medium')
    }

    getProductTitle(){
        return cy.get('#title')
    }

    getProductPrice(){
        return cy.get('#priceblock_ourprice')
    }

   goToShoesSearch(input){

        this.getSearchBox().type(input)
        this.getSubmitButton().click()
        this.getSearchedResponse().should('include.text',input)
    }

    goToShoesSearchAndApplyFilters(input,brandfilter){
        this.goToShoesSearch(input)
        this.getBrandFilter(brandfilter).click()
        this.getUnder500Filter().click()
        

    }
    

}

export default AmazonSearch